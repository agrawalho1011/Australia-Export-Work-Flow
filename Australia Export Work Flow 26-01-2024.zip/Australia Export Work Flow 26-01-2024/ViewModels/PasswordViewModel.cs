﻿namespace AustraliaExportTrackX.ViewModels
{
    public class PasswordViewModel
    {
        public string? Id { get; set; }
        public string? OldPassword { get; set; }
        public string? Password { get; set; }
        public string? ConfirmPassword { get; set; }
    }
}
