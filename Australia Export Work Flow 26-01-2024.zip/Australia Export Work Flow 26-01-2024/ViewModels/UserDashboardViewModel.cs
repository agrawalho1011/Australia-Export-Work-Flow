﻿namespace APACExportTrackX.ViewModels
{
    public class UserDashboardViewModel
    {
        public UserDashboardViewModel()
        {
            HBLStatusCount = new List<HBLStatusCount>();
            HBLCount = new List<HBLCount>();
            HBLStatusCounts = new List<HBLStatusCount>();
        }
        public string User { get; set; }
        public int Total { get; set; }
        public int Count { get; set; }
        public int Query { get; set; }
        public int WIP { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }


        public int TotalCompleted { get; set; }
        public int TotalQuery { get; set; }
        public int TotalPending { get; set; }
        public int TotalWIP { get; set; }
        public int TotalCompletedWithQuery { get; set; }
        public List<HBLCount> HBLCount { get; set; }
        public List<HBLStatusCount> HBLStatusCount { get; set; }
        public List<HBLStatusCount> HBLStatusCounts { get; set; }
        //public List<EDIThreadCount> EDIThreadData { get; set; }

    }
    public class HBLCount
    {
        public string ActivityId { get; set; }
        public string Status { get; set; }
        public int Count { get; set; }
        public int Completed { get; set; }
        public int Pending { get; set; }
        public int Query { get; set; }
        public int WIP { get; set; }
    }
    public class HBLStatusCount
    {
        public string ActivityId { get; set; }
        public int Count { get; set; }
        public int Query { get; set; }
        public int WIP { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }
        public int TotalCompleted { get; set; }
        public int TotalQuery { get; set; }
        public int TotalPending { get; set; }
        public int TotalWIP { get; set; }
    }
}
