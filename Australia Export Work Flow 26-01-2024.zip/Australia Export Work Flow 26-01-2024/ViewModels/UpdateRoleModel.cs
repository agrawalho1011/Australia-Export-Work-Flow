﻿namespace APACExportTrackX.ViewModels
{
	public class UpdateRoleModel
	{
		public string? CitrixId { get; set; }
		public string? RoleId { get; set; }
	}
}
