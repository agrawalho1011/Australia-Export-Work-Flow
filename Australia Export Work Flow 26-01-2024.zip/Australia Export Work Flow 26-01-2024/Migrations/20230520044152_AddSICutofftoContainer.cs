﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace APACExportTrackX.Migrations
{
    public partial class AddSICutofftoContainer : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SICutOff",
                table: "FileMaster");

            migrationBuilder.AddColumn<DateTime>(
                name: "SICutOff",
                table: "ContainerMaster",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SICutOff",
                table: "ContainerMaster");

            migrationBuilder.AddColumn<DateTime>(
                name: "SICutOff",
                table: "FileMaster",
                type: "datetime2",
                nullable: true);
        }
    }
}
