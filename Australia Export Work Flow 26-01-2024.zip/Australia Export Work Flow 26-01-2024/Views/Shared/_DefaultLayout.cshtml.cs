using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AustraliaExportTrackX.Views.Shared
{
    public class _DefaultLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
