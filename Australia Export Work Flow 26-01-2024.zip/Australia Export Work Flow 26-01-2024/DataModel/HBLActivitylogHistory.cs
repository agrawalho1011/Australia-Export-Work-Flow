﻿using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{
    public class HBLActivitylogHistory
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string HBLogId { get; set; }

        public string ActivityId { get; set; } 

        public string StatusId { get; set; }

        public string? Comment { get; set; }

        public string UserId { get; set; } = null!;

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        [ForeignKey("HblLogId")]
        public virtual HBLActivityLog HBLActivityLog { get; set; } = null!;

        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; } = null!;

        [ForeignKey("ActivityId")]
        public virtual ActivityMaster Activity { get; set; } = null!;

        [ForeignKey("StatusId")]
        public virtual StatusMaster Status { get; set; } = null!;

        
    }
}
