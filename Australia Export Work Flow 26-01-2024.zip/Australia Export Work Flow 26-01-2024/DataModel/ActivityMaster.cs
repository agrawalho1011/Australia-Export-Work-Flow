﻿using System;
using APACExportTrackX.DataModel;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{
    public partial class ActivityMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string NameOfActivity { get; set; } = null!;

        public string ActivityType { get; set; } = null!;

        public string? Source { get; set; } = null!;

        public int? FileSequence { get; set;}

        public bool? IsActive { get; set; } = true;
        public bool? IsDelete { get; set; } = false;

        public virtual ICollection<FileActivityLog> FileActivityLogs { get; } = new List<FileActivityLog>();

        public virtual ICollection<HBLActivityLog> HBLActivityLogs { get; } = new List<HBLActivityLog>();
    }

}